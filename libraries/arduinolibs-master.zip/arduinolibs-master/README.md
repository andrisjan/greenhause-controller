
Arduino Libraries
=================

This distribution contains a bunch of libraries and example applications
that I have made for Arduino, covering a variety of tasks from blinking LED's
to LCD's and RTC-based alarm clocks.  They are distributed under the
terms of the MIT license.

The [documentation](http://rweather.github.com/arduinolibs/index.html)
contains more information on the libraries and examples.

For more information on these libraries, to report bugs, or to suggest
improvements, please contact the author Rhys Weatherley via
[email](mailto:rhys.weatherley@gmail.com).
